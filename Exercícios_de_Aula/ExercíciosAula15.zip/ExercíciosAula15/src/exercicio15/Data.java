package exercicio15;
public class Data {

    private int dia;
    private int mes;
    private int ano;

    public Data(int dia, int mes, int ano) {
        validarData(dia, mes, ano);

        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public void validarData(int dia, int mes, int ano) {

        if (mes < 1 || mes > 12) {
            throw new IllegalArgumentException("Mês inválido.");
        }

        int diasNoMes;

        switch (mes) {
            case 4:
            case 6:
            case 9:
            case 11:
                diasNoMes = 30;
                break;

            case 2:
                diasNoMes = 28;
                break;

            default:
                diasNoMes = 31;
        }

        if (dia < 1 || dia > diasNoMes) {
            throw new IllegalArgumentException("Data inválida.");
        }
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + ano;
    }
}