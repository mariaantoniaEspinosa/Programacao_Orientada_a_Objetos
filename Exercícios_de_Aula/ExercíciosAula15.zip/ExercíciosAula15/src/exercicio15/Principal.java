package exercicio15;

public class Principal {

    public static void main(String[] args) {

        try {
            Data d1 = new Data(15, 6, 2025);
            System.out.println("Data válida: " + d1);

            Data d2 = new Data(31, 2, 2025);
            System.out.println("Data válida: " + d2);

        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
