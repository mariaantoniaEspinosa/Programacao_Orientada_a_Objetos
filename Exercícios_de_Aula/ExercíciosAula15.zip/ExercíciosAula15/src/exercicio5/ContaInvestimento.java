package exercicio5;

public class ContaInvestimento extends Conta{

	public ContaInvestimento(double saldo) {
		super(saldo);
	}
	
	public void atualizarRendimento() {
		double rendimento = saldo * 0.05;
		saldo = saldo + rendimento;
		
		System.out.println("Rendimento de 5% aplicado: " + rendimento);
		System.out.println("Novo saldo em reais: " + saldo);
	}
	
}
