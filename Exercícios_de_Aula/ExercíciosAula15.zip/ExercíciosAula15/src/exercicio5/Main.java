package exercicio5;

public class Main {
	public static void main(String[] args) {
		ContaInvestimento cInvest = new ContaInvestimento(1000);
		ContaPoupanca cPoup = new ContaPoupanca(1000);
		
		System.out.println("CONTA INVESTIMENTO");
		cInvest.atualizarRendimento();
		
		System.out.println("CONTA POUPANÇA");
		cPoup.atualizarJuros();
	}
}
