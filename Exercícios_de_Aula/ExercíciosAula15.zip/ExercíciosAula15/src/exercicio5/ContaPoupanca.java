package exercicio5;

public class ContaPoupanca extends Conta {

	public ContaPoupanca(double saldo) {
		super(saldo);
	}
	
	public void atualizarJuros() {
		double juros = saldo * 0.03;
		saldo = saldo + juros;
		
		System.out.println("Juros de 3% aplicado: " + juros);
		System.out.println("Novo saldo: " + saldo);
	}

}
