package exercicio5;

public abstract class Conta {
	protected double saldo;

	public Conta(double saldo) {
		super();
		this.saldo = saldo;
	}
	
	public void deposiar(double valor) {
		saldo = saldo +  valor;
		System.out.println("Deposito realizado: " + valor + "reais");
	}
	
	public void sacar(double valor) {
		if(valor<= saldo) {
			saldo = saldo - valor;
			System.out.println("Saque realizado: " + valor + "reais");
		} 
		else {
			System.out.println("Saldo insuficiente");
		}
		
		
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
}
