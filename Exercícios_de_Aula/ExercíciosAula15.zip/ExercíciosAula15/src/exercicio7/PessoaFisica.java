package exercicio7;

public class PessoaFisica extends Pessoa{

	private String cpf;
	
	public PessoaFisica(String nome, String cidade, String cpf) {
		super(nome, cidade);
		this.cpf = cpf;
	}

	@Override
	public void efetuarCompra() {
		System.out.println("Pessoa física está efetuando a compra");
		System.out.println("CPF: " + cpf);
	}
	
}
