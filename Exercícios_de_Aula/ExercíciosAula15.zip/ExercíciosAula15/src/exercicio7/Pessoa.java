package exercicio7;

public abstract class Pessoa {
	protected String nome;
	protected String cidade;
	
	public abstract void efetuarCompra();

	public Pessoa(String nome, String cidade) {
		super();
		this.nome = nome;
		this.cidade = cidade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	
	
}
