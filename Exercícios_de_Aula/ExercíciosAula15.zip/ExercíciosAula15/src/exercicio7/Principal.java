package exercicio7;

public class Principal {
	public static void main(String[] args) {
		PessoaFisica pf = new PessoaFisica("Maria", "Santa Maria", "04776751070");
		PessoaJuridica pj = new PessoaJuridica("Marcia", "Santa Maria", "07.119.129/0001-62");
		
		System.out.println("PESSOA FÍSICA");
		System.out.println(pf.getNome() + " - " + pf.getCidade());
		pf.efetuarCompra();
		
		System.out.println("PESSOA JURÍDICA");
		System.out.println(pj.getNome() + " - " + pj.getCidade());
		pj.efetuarCompra();
	}
}
