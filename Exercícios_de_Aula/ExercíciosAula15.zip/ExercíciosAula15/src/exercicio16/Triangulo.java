package exercicio16;

public class Triangulo {
	private double lado1;
	private double lado2;
	private double lado3;
	
	public Triangulo(double lado1, double lado2, double lado3) {
		super();
		validar(lado1, lado2, lado3);
		this.lado1 = lado1;
		this.lado2 = lado2;
		this.lado3 = lado3;
	}
	
	public void validar(double lado1, double lado2, double lado3) {
		if(lado1<=0 || lado2<=0 || lado3 <=0) {
			throw new IllegalArgumentException("Os lados devem ser maiores que zero");
		}
		
		if(lado1 + lado2 <= lado3 || lado1 + lado3 <= lado2 || lado2 + lado3 <= lado1) {
			throw new IllegalArgumentException("Valores inválidos");
		}
	}
	
	@Override
	public String toString() {
		return "Triângulo: " + lado1 + ", " + lado2 + ", " + lado3;
	}
}
