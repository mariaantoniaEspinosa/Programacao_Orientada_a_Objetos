package exercicio16;

public class Principal {

	public static void main(String[] args) {
		try {
			Triangulo t = new Triangulo(3, 4, 5);
			System.out.println(t);
			
			Triangulo t2 = new Triangulo (2, 3, 10);
			System.out.println(t2);
		} catch (IllegalArgumentException e) {
			System.out.println("Erro: " + e.getMessage());
		}

	}

}
