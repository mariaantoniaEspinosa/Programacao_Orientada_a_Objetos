package exercicio6;

public class Principal {

	public static void main(String[] args) {
		Carro c = new Carro ("Uno", "Fiat", 1992);
		Moto m = new Moto ("Biz", "Honda", 2023);
		
		System.out.println("CARRO");
		System.out.println(c.getMarca() + " " + c.getModelo());
		c.acelerar();
		c.frear();
		
		System.out.println("MOTO");
		System.out.println(m.getMarca() + " " + m.getModelo());
		m.acelerar();
		m.frear();

	}

}
