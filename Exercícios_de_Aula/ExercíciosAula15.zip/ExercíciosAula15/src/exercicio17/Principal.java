package exercicio17;

public class Principal {

    public static void main(String[] args) {

        Agenda agenda = new Agenda();

        try {
            agenda.adicionarContato("Maria", "99999-9999");

            agenda.adicionarContato("", "88888-8888");

        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
