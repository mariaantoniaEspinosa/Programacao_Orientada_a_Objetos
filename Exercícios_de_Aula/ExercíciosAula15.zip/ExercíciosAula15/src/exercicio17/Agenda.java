package exercicio17;

public class Agenda {
    public void adicionarContato(String nome, String telefone) {

        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome inválido.");
        }

        if (telefone == null || telefone.trim().isEmpty()) {
            throw new IllegalArgumentException("Telefone inválido.");
        }

        System.out.println("Contato adicionado com sucesso!");
        System.out.println("Nome: " + nome);
        System.out.println("Telefone: " + telefone);
    }
}
