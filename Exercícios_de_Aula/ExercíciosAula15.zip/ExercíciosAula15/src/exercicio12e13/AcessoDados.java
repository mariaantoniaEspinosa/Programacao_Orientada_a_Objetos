package exercicio12e13;

public interface AcessoDados {
	void conectar();
	void desconectar();
	void inserir();
	void atualizar();
	void excluir();
}
