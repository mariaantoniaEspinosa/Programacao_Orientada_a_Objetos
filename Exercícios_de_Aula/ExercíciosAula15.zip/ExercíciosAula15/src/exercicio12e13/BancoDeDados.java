package exercicio12e13;

public class BancoDeDados implements AcessoDados{

	@Override
	public void conectar() {
		System.out.println("Conecta ao Banco ");
	}

	@Override
	public void desconectar() {
		System.out.println("Desconecta do Banco");
	}

	@Override
	public void inserir() {
		System.out.println("Insere no Banco");
	}

	@Override
	public void atualizar() {
		System.out.println("Atualiza o Banco");
	}

	@Override
	public void excluir() {
		System.out.println("Exclui o Banco");
	}

}
