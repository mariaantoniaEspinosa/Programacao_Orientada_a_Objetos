package exercicio10e11;

public class Livro implements Produto{
	private String nome;
	private double preco;
	private String descricao;
	
	public Livro(String nome, double preco, String descricao) {
		super();
		this.nome = nome;
		this.preco = preco;
		this.descricao = descricao;
	}
	@Override
	public String getNome() {
		return nome;
	}
	@Override
	public double getPreco() {
		return preco;
	}
	@Override
	public String getDescricao() {
		return descricao;
	}
}
