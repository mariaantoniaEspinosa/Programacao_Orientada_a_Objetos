package exercicio10e11;

public interface Produto {
	String getNome();
	double getPreco();
	String getDescricao();
}
