package exercicio10e11;

public class Principal {
	public static void main(String[] args) {
		Livro l = new Livro ("HP ", 59.90, " Livro Infantil");
		CD cd = new CD ("Hits ", 15.90, " Hits anos 2000");
		
		System.out.println("LIVRO");
		System.out.println(l.getNome() + l.getPreco() + l.getDescricao());
		
		System.out.println("CD");
		System.out.println(cd.getNome() + cd.getPreco() + cd.getDescricao());
	}
}
