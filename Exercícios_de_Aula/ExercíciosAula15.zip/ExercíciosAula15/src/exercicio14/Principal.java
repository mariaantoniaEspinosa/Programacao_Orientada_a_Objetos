package exercicio14;

public class Principal {

	public static void main(String[] args) {
		try {
			Pessoa P = new Pessoa("Maria", -25);
			System.out.println("Pessoa cadastrada com sucesso");
		} catch (Exception e ) {
			System.out.println("Erro: " + e.getMessage());
		}

	}

}
