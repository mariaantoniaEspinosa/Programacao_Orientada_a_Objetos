package exercicio14;

public class Pessoa {
	private String nome;
	private int idade;
	
	public Pessoa(String nome, int idade) throws Exception{
		this.nome = nome;
		validarIdade(idade);
		this.idade = idade;
	}

	private void validarIdade(int idade) throws Exception {
		if (idade< 0 || idade > 120) {
			throw new Exception("Idade inválida!");
		}
	}

	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}
	
		
}

