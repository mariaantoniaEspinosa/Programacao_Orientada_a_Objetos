package exercicio8;

public class Gerente extends Funcionario {
	
	private double bonus;

	public Gerente(String nome, double salario) {
		super(nome, salario);
	}

	@Override
	public void calcularSalario() {
		bonus = salario * 0.2;
		salario = salario + bonus;
		System.out.println("Salario do gerente (com bonus) em reais: " + salario);
	}

	
}
