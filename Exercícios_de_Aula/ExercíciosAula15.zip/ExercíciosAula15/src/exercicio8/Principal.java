package exercicio8;

public class Principal {

	public static void main(String[] args) {
		Gerente g = new Gerente ("Maria", 1200);
		Vendedor v = new Vendedor ("Marcia", 1300);
		
		System.out.println("GERENTE");
		System.out.println(g.getNome());
		System.out.println("Salario sem bonus: " + g.getSalario());
		g.calcularSalario();
		
		System.out.println("VENDEDOR");
		System.out.println(v.getNome());
		v.calcularSalario();
		

	}

}
