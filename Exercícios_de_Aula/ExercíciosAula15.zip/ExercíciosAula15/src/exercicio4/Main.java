package exercicio4;

public class Main {

	public static void main(String[] args) {
		Cachorro c = new Cachorro();
		c.setNome("Max");
		c.setIdade(2);
		
		Gato g = new Gato();
		g.setNome("Magul");
		g.setIdade(5);
		
		System.out.println("Cachorro: " + c.getNome());
		System.out.println("Idade: " + c.getIdade());
		c.emitirSom();
		
		System.out.println("Gato: " + g.getNome());
		System.out.println("Idade: " + g.getIdade());
		g.emitirSom();
	}

}
